﻿$(document).ready(function () {
  showLoader();
  if (config.envi == 'dev') {
      inntScript();
  }
   
});
//*********************loader */
function showLoader() {
  $.blockUI({
    message: '<div id="page-preloader"><span class="spinner"></span></div>',
    css: {
      border: 'none',
    }
  });
}

function hideLoader() {
  $.unblockUI();
}

function inntScript() {
    if (config.envi == 'dev') {
      localStorage.setItem('useremail', "viewer@uat.gmail.com");
    init().then(function(){
      pageStartup();
    })
     
    } 
};

var ColorCompetency = [{ 'r': 186, 'g': 196, 'b': 5 }, { 'r': 207, 'g': 18, 'b': 38 }, { 'r': 0, 'g': 183, 'b': 198 }, { 'r': 0, 'g': 54, 'b': 163 }, { 'r': 249, 'g': 86, 'b': 2 }, { 'r': 252, 'g': 209, 'b': 22 }]

async function init() {
  clicks();
  PageTransitions.init();
  HandlebarsHelpers();
  $('.owl-carousel').owlCarousel({
    items: 1,
  });
}


//****************ajax requests */
function getAllUsersInfo() {
  var prom = Q.defer();

  var headers = {
    'Content-Type': 'application/json'
  };

  var fnSuccess = function (resp) {
    console.log(resp)
    prom.resolve(resp);
  };

  var fnError = function (err) {
    prom.reject(err)
  };

  fnAjaxRequest(config.baseUrl+"users", 'GET', headers, {}, fnSuccess, fnError);

  return prom.promise;
};
function getUserPosts(uid) {
  var prom = Q.defer();

  var headers = {
    'Content-Type': 'application/json'
  };

  var fnSuccess = function (resp) {
    console.log(resp)
    prom.resolve(resp);
  };

  var fnError = function (err) {
    prom.reject(err)
  };

  fnAjaxRequest(config.baseUrl+"posts?userId="+uid+"&skip=0&limit=10", 'GET', headers, {}, fnSuccess, fnError);

  return prom.promise;
};
function getAllComments() {
  var prom = Q.defer();

  var headers = {
    'Content-Type': 'application/json'
  };

  var fnSuccess = function (resp) {
    console.log(resp)
    prom.resolve(resp);
  };

  var fnError = function (err) {
    prom.reject(err)
  };

  fnAjaxRequest(config.baseUrl+"posts/2/comments", 'GET', headers, {}, fnSuccess, fnError);

  return prom.promise;
};
//********all global variables  */
var allUsersInfo;
var allPostSingleEmp;
var clicks = function () {
 
  $('body').off('click', '.backBtn').on('click', '.backBtn', function (e) {
    if ($(this).hasClass('btn-1')) {
      PageTransitions.nextPage(1, 21, false)
    }
  })
  $('body').off('click', '.view').on('click', '.view', function (e) {
    var uid= $(this)[0].getAttribute('data-uid')
    getUserPosts(uid).then(function(resp){
      allPostSingleEmp = resp;
      PageTransitions.nextPage(2, 21, false)
      var cardHtml = fnHandleBars("eachPost_template", resp);
      $('#postHB').html(cardHtml);
    })
  
    
  })
  $('body').off('click', '.commentInfo').on('click', '.commentInfo', function (e) {
   showLoader();
    getAllComments().then(function(resp2){
      var cardHtml = fnHandleBars("eachComment_template", resp2);
      $('#commentHB').html(cardHtml);
      $('.commentPage').removeClass('hide')
      hideLoader();
    })
  })
  $('body').off('click', '.commentWindow').on('click', '.commentWindow', function (e) {
    $('.commentPage').addClass('hide')
  })
  $('body').off('click', '.comClose').on('click', '.comClose', function (e) {
    $('.commentPage').addClass('hide')
  })
  $('body').off('click', '.pt2-arrow-back').on('click', '.pt2-arrow-back', function (e) {
    PageTransitions.nextPage(1, 22, false)
  })
  $('body').off('keyup', '.pt2-searchBox input').on('keyup', '.pt2-searchBox input', function (e) {
    var filterTxt = $(this)[0].value.toLowerCase();
    var tempPosts = allPostSingleEmp.filter(el => el.title.toLowerCase().includes(filterTxt) || el.body.toLowerCase().includes(filterTxt));
    var cardHtml = fnHandleBars("eachPost_template", tempPosts);
      $('#postHB').html(cardHtml);

  })
  $('body').off('keyup', '.searchEmp input').on('keyup', '.searchEmp input', function (e) {
    var filterTxt = $(this)[0].value.toLowerCase();
    var tempUsers = allUsersInfo.filter(el => el.name.toLowerCase().includes(filterTxt) || el.company.name.toLowerCase().includes(filterTxt));
    var cardHtml = fnHandleBars("eachEmp_template", tempUsers);
    $('#empHB').html(cardHtml);

  })
}

var HandlebarsHelpers = function () {


  Handlebars.registerHelper('ifeq', function (v1, v2, options) {
    
    if (v1 === v2) {
      return options.fn(this);
    }
    return options.inverse(this);
  });

}

function fnHandleBars(template, data) {
  template = "#" + template;
  var Source = $(template).html();
  var fnTemplate = Handlebars.compile(Source);
  return fnTemplate(data);
};

var fnHandlebarsScript = function (source, destination, data) {
  var source = $(source).html();
  var fnHandle = Handlebars.compile(source);
  var htmlvar = fnHandle(data);
  $(destination).html(htmlvar)
};

function fnAjaxRequest(ajaxURL, ajaxReqMethod, ajaxReqHeader, ajaxReqData, onSucess, onError) {
  $.ajax({
    type: ajaxReqMethod,
    url: ajaxURL,
    headers: ajaxReqHeader,
    data: ajaxReqData,
    success: onSucess,
    error: onError
  });
};

function constructJson(jsonKey, jsonValue) {
  json[jsonKey] = jsonValue;
  return json;
}
window.addEventListener('online', updateOnline);
window.addEventListener('offline', updateStatus);

function updateStatus() {
  if (navigator.onLine) {

  }
  else {
    localStorage.setItem('OpenOffline', true);
    swal({
      icon: 'info',
      text: 'There seem to be an issue with your network connectivity. Please connect to the internet and try again.',
      buttons: {
        confirm: {
          //text: 'Agree',
          text: "OK",
          visible: true,
          value: true
        },
      },
    })
  }
}

function updateOnline() {
  if (localStorage.getItem('OpenOffline') == "true") {
    swal({
      icon: 'info',
      text: 'We are Back !',
      buttons: {
        confirm: {
          text: "Agree",
          visible: true,
          value: true
        },
      },
    }).then(function () {
      localStorage.setItem('OpenOffline', false);
    })
  }
}
function pageStartup() {
  showLoader()
  getAllUsersInfo().then(function(resp){
    allUsersInfo = resp;
    var cardHtml = fnHandleBars("eachEmp_template", resp);
      $('#empHB').html(cardHtml);
    hideLoader();
  })
}

