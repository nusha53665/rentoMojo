
var config = {
 "baseUrl": "https://jsonplaceholder.typicode.com/", 
  "envi": "dev",
}
